package z.practice.exception.ex2;

public class NumRangeException extends Exception{
	public NumRangeException() {
		super();
	}
	
	public NumRangeException(String message) {
		super(message);
	}
}
