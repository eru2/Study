package z.practice.oop.ex6;

public class Run {

	public static void main(String[] args) {
		MemberMenu mm = new MemberMenu();
		mm.mainMenu();
	}

}
