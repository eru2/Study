/**
 * 
 */
/**
 * 
 */
module JavaStudy {
}