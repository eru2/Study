package z.practice.object.ex2;

import java.util.Date;
 
public class Ticket {
	String movieId;
	int price;
	String seatNumber;
	Date showTime;
}
