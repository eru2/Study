package z.practice.inherit.ex2;

public class Run {

	public static void main(String[] args) {
		new PersonMenu().mainMenu();
	}

}
