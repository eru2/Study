package z.practice.inherit.ex1;

public class Run {

	public static void main(String[] args) {
		new PointMenu().mainMenu();
	}

}
