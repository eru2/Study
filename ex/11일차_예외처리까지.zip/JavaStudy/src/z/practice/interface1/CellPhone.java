package z.practice.interface1;

public interface CellPhone extends Phone, Camera{
	public abstract String charge();
}
