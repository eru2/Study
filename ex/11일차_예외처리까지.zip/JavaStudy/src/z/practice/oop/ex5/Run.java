package z.practice.oop.ex5;

public class Run {
	public static void main(String[] args) {
		StudentMenu sm = new StudentMenu();
	}
}
