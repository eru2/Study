package z.practice.oop.ex1;

//프로그램의 시작부
public class Run {

	public static void main(String[] args) {
		new ShapeMenu().inputMenu(); //프로그램의 시작메서드
	}

}
