package j.interface1;

public interface Baby { //baby인지 체크하기위한 interface

}
