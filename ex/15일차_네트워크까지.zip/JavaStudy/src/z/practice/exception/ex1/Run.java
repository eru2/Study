package z.practice.exception.ex1;

public class Run {

	public static void main(String[] args) {
		new CharacterMenu().menu();
	}

}
