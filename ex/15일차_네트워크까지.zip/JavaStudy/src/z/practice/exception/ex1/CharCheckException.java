package z.practice.exception.ex1;

public class CharCheckException extends RuntimeException{

	public CharCheckException() {
		super();
	}

	public CharCheckException(String message) {
		super(message);
	}
	
}
