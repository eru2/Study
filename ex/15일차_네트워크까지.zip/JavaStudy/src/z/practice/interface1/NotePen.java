package z.practice.interface1;

public interface NotePen {
	boolean PEN_BUTTON = true;
	
	boolean bluetoothPen();
}
