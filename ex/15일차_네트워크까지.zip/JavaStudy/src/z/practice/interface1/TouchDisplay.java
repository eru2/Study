package z.practice.interface1;

public interface TouchDisplay {
	String touch();
}
