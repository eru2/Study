package z.practice.interface1;

public interface Camera {
	String picture();
}
