package z.practice.io;

public class Run {

	public static void main(String[] args) {
		FileMenu fm = new FileMenu(); 
		fm.mainMenu();
	}

}
