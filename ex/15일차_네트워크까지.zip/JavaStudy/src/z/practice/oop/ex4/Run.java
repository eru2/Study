package z.practice.oop.ex4;

public class Run {

	public static void main(String[] args) {
		EmployeeMenu em = new EmployeeMenu();
	}

}
