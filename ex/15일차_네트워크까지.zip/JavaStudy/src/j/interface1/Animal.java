package j.interface1;

public interface Animal {
	//static final변수
	//추상메서드 : 미완성 메서드로 구현부({})가 없는 메서드
	//abstract 추상키워드를 붙여서 생성
	public abstract void move();
	/*public abstract*/void eat();
	void makeSound();
}
